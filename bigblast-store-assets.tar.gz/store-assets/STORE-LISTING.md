# Big Blast — Play Store Assets

Everything Google requires for the listing, ready to upload.

## Files

| File | Size | Where it goes |
|---|---|---|
| `icon-512.png` | 512×512 | Play Console → Store listing → App icon |
| `feature-1024x500.png` | 1024×500 | Store listing → Feature graphic |
| `screen-1-menu.png` | 1080×1920 | Phone screenshots |
| `screen-2-gameplay.png` | 1080×1920 | Phone screenshots |
| `screen-3-modes.png` | 1080×1920 | Phone screenshots |
| `screen-4-themes.png` | 1080×1920 | Phone screenshots |
| `screen-5-stats.png` | 1080×1920 | Phone screenshots |

Google needs a minimum of 2 phone screenshots; 5 is the sweet spot. Order
matters — most people only look at the first two, so keep menu and gameplay
first.

`icon-96-check.png` is not for upload. It's the icon rendered at launcher size
to confirm it stays legible when small.

---

## Short description (80 character limit)

Use one of these. Character counts are exact.

**Recommended (72):**
> Drag, fit and clear blocks. Simple to start, hard to put down.

Alternatives:
- (63) `Fill rows, chain combos, beat your best. A block puzzle to master.`
- (79) `A block puzzle with room to think. 7 modes, no timers unless you want one.`

---

## Full description

```
Fit blocks onto the board. Fill a row or column and it clears. Chain
clears together for combos and watch your score climb.

Easy to pick up. The depth comes from what you choose to do with an
awkward piece.

WHAT'S IN IT

• Seven ways to play — Classic, Time Attack, Zen, Daily Puzzle,
  Challenge, Pure, and pass-and-play Duel for two people on one phone
• A hold slot — bank a piece for later when it doesn't fit right now
• Ranks from Bronze to Supernova, earned through play
• Themes to unlock, from clean and simple to a full animated nebula
• Daily and weekly challenges, and a login streak worth keeping
• Undo, bombs and lasers for when the board gets tight
• Lifetime stats and a personal top ten to beat

BUILT TO RESPECT YOU

• No account, no sign-up — nothing to create or log into
• Your progress stays on your device
• Full support for reduced-motion accessibility settings
• Occasional ads keep it free — see our privacy policy for what that involves

Every set of pieces you're dealt is checked to make sure it can actually
be placed. If you get stuck, it's because of a decision you made — not
because the game handed you something impossible.
```

---

## Content rating questionnaire

Answer honestly; for this game it's all "no": no violence, no sexual content,
no profanity, no drugs, no gambling or simulated gambling, no user-to-user
communication, no location sharing, no personal information collected.

Expect an **Everyone / PEGI 3** rating.

---

## Category and tags

- **Application type:** Game
- **Category:** Puzzle
- **Tags:** Casual, Brain Games, Single player, Offline

---

## Notes on the assets

The icon is built from the game's own visual language — a plus piece from the
actual game, in the real block colours, on the board's grid. It deliberately
carries no text, since text is unreadable at launcher size, and it was checked
at 96px to confirm the shape still reads.

The screenshots are captured from the real running game, not mockups. If you
change the UI meaningfully, re-capture rather than shipping stale images.
